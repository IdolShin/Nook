const webpush = require('web-push')
const supabase = require('../db/supabase')

// Initialize VAPID keys
if (process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(
    process.env.VAPID_EMAIL,
    process.env.VAPID_PUBLIC_KEY,
    process.env.VAPID_PRIVATE_KEY
  )
}

const pushService = {

  // Send push to a single customer
  async sendToCustomer(customer, message, businessName) {
    try {
      if (!customer.device_token) return { skipped: true, reason: 'no device_token' }

      // device_token is a JSON string with { endpoint, keys: { p256dh, auth } }
      let subscription
      try {
        subscription = JSON.parse(customer.device_token)
      } catch {
        return { skipped: true, reason: 'invalid device_token format' }
      }

      const payload = JSON.stringify({
        title:   businessName || 'Nook',
        body:    message,
        icon:    '/icons/icon-192.png',
        badge:   '/icons/badge-72.png',
        tag:     'nook-stamp',
        renotify: true
      })

      await webpush.sendNotification(subscription, payload)

      // Log it
      await supabase.from('push_logs').insert({
        business_id: customer.business_id,
        customer_id: customer.id,
        message,
        status: 'sent'
      })

      return { sent: true }
    } catch (err) {
      console.error('Push failed for customer', customer.id, err.message)

      await supabase.from('push_logs').insert({
        customer_id: customer.id,
        message,
        status: 'failed'
      })

      return { sent: false, error: err.message }
    }
  },

  // Broadcast push to all customers of a card
  async broadcastToCard(cardId, message, businessName) {
    try {
      const { data: customers, error } = await supabase
        .from('customers')
        .select('id, device_token, business_id')
        .eq('card_id', cardId)
        .eq('consent_push', true)
        .not('device_token', 'is', null)

      if (error) throw error

      const results = await Promise.allSettled(
        customers.map(c => pushService.sendToCustomer(c, message, businessName))
      )

      const sent   = results.filter(r => r.status === 'fulfilled' && r.value?.sent).length
      const failed = results.length - sent

      return { total: customers.length, sent, failed }
    } catch (err) {
      console.error('Broadcast error:', err)
      return { error: err.message }
    }
  },

  // Apple Wallet pass push update (separate from web push)
  // Tells Apple servers to fetch updated pass from /api/wallet/v1/passes/...
  async updateApplePass(passTypeId, serialNumber) {
    // Apple push is handled by passkit / node-passkit-generator in Step 5
    // Placeholder here
    console.log(`[Apple Wallet] update push → ${passTypeId}:${serialNumber}`)
    return { queued: true }
  }
}

// ─── POST /api/push/broadcast ────────────────────────────────
// Dashboard에서 전체 고객에게 메시지 발송
const express = require('express')
const router = express.Router()
const { authMiddleware } = require('../middleware/auth')

router.post('/broadcast', authMiddleware, async (req, res) => {
  try {
    const { card_id, message } = req.body
    if (!card_id || !message) {
      return res.status(400).json({ error: 'card_id and message required' })
    }
    if (message.length > 140) {
      return res.status(400).json({ error: 'Message max 140 chars' })
    }

    const result = await pushService.broadcastToCard(card_id, message, req.business.name)
    res.json(result)
  } catch (err) {
    res.status(500).json({ error: 'Broadcast failed' })
  }
})

module.exports = { router, pushService }
